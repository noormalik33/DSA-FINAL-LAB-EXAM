#include <iostream>
#include <vector>
#include <string>
using namespace std;

class TreeNode {
public:
    string name;
    bool isCourse;
    vector<TreeNode*> children;

    TreeNode(string name, bool isCourse = false) : name(name), isCourse(isCourse) {}
};

class UniversityTree {
private:
    TreeNode* root;

    void preOrderTraversal(TreeNode* node, int level) {
        if (node == nullptr) return;
        for (int i = 0; i < level; i++) cout << "  ";
        cout << node->name << (node->isCourse ? " (Course)" : " (Department)") << endl;
        for (TreeNode* child : node->children) {
            preOrderTraversal(child, level + 1);
        }
    }

    bool search(TreeNode* node, const string& name, vector<string>& path) {
        if (node == nullptr) return false;
        path.push_back(node->name);
        if (node->name == name) {
            return true;
        }
        for (TreeNode* child : node->children) {
            if (search(child, name, path)) {
                return true;
            }
        }
        path.pop_back();
        return false;
    }

    bool deleteNode(TreeNode* parent, const string& name) {
        for (auto it = parent->children.begin(); it != parent->children.end(); ++it) {
            TreeNode* child = *it;
            if (child->name == name) {
                if (!child->isCourse && !child->children.empty()) {
                    cout << "Cannot delete non-empty department: " << name << endl;
                    return false;
                }
                parent->children.erase(it);
                delete child;
                return true;
            }
            if (deleteNode(child, name)) {
                return true;
            }
        }
        return false;
    }

public:
    UniversityTree(string rootName) {
        root = new TreeNode(rootName);
    }

    void addDepartmentOrCourse(string parentName, string name, bool isCourse) {
        TreeNode* parentNode = searchNode(root, parentName);
        if (parentNode) {
            parentNode->children.push_back(new TreeNode(name, isCourse));
        } else {
            cout << "Parent department not found!" << endl;
        }
    }

    void deleteDepartmentOrCourse(string name) {
        if (!deleteNode(root, name)) {
            cout << "Department/Course not found or cannot be deleted!" << endl;
        }
    }

    void displayHierarchy() {
        preOrderTraversal(root, 0);
    }

    void searchDepartmentOrCourse(string name) {
        vector<string> path;
        if (search(root, name, path)) {
            cout << "Path to " << name << ": ";
            for (size_t i = 0; i < path.size(); ++i) {
                cout << path[i];
                if (i != path.size() - 1) cout << " -> ";
            }
            cout << endl;
        } else {
            cout << name << " not found in the university!" << endl;
        }
    }

private:
    TreeNode* searchNode(TreeNode* node, const string& name) {
        if (node == nullptr) return nullptr;
        if (node->name == name) return node;
        for (TreeNode* child : node->children) {
            TreeNode* found = searchNode(child, name);
            if (found) return found;
        }
        return nullptr;
    }
};

int main() {
    UniversityTree university("AIR University");

    university.addDepartmentOrCourse("AIR University", "Engineering", false);
    university.addDepartmentOrCourse("AOR University", "Sciences", false);
    university.addDepartmentOrCourse("Engineering", "Civil Engineering", true);
    university.addDepartmentOrCourse("Engineering", "Electrical Engineering", true);
    university.addDepartmentOrCourse("Sciences", "Physics", true);

    cout << "University Hierarchy:" << endl;
    university.displayHierarchy();

    university.searchDepartmentOrCourse("Civil Engineering");

    university.deleteDepartmentOrCourse("Physics");
    university.deleteDepartmentOrCourse("Engineering");

    cout << "\nUniversity Hierarchy after Deletions:" << endl;
    university.displayHierarchy();

    university.searchDepartmentOrCourse("Physics");

    return 0;
}

