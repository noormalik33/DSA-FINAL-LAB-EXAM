#include <iostream>
#include <vector>
#include <queue>
#include <unordered_map>
#include <climits>
#include <stack>

using namespace std;

class Graph {
public:
    unordered_map<string, vector<pair<string, int>>> adjList;

    void addRoad(const string& location1, const string& location2, int distance) {
        adjList[location1].push_back({location2, distance});
        adjList[location2].push_back({location1, distance});
    }

    bool areLocationsConnected(const string& start, const string& end) {
        if (start == end) return true;

        unordered_map<string, bool> visited;
        queue<string> q;
        q.push(start);
        visited[start] = true;

        while (!q.empty()) {
            string current = q.front();
            q.pop();
            for (auto& neighbor : adjList[current]) {
                string nextLocation = neighbor.first;
                if (nextLocation == end) return true;
                if (!visited[nextLocation]) {
                    visited[nextLocation] = true;
                    q.push(nextLocation);
                }
            }
        }
        return false;
    }

    void shortestPath(const string& start, const string& end) {
        unordered_map<string, int> distances;
        unordered_map<string, string> previous;
        priority_queue<pair<int, string>, vector<pair<int, string>>, greater<pair<int, string>>> pq;

        for (const auto& entry : adjList) {
            distances[entry.first] = INT_MAX;
        }
        distances[start] = 0;
        pq.push({0, start});

        while (!pq.empty()) {
            string current = pq.top().second;
            int currentDist = pq.top().first;
            pq.pop();

            if (current == end) break;

            for (auto& neighbor : adjList[current]) {
                string nextLocation = neighbor.first;
                int weight = neighbor.second;
                int newDist = currentDist + weight;

                if (newDist < distances[nextLocation]) {
                    distances[nextLocation] = newDist;
                    previous[nextLocation] = current;
                    pq.push({newDist, nextLocation});
                }
            }
        }

        stack<string> path;
        string current = end;
        while (!current.empty() && previous.find(current) != previous.end()) {
            path.push(current);
            current = previous[current];
        }
        path.push(start);

        if (distances[end] != INT_MAX) {
            cout << "\n===== Shortest Path =====\n";
            cout << "From: " << start << "\nTo: " << end << "\nPath: ";
            while (!path.empty()) {
                cout << path.top();
                path.pop();
                if (!path.empty()) cout << " -> ";
            }
            cout << "\nTotal Distance: " << distances[end] << " units\n";
            cout << "=========================\n";
        } else {
            cout << "\nNo path found between " << start << " and " << end << ".\n";
        }
    }
};


int main() {
    Graph cityMap;

    cityMap.addRoad("CityX", "CityY", 7);
    cityMap.addRoad("CityY", "CityZ", 12);
    cityMap.addRoad("CityZ", "CityW", 4);
    cityMap.addRoad("CityX", "CityW", 18);
    cityMap.addRoad("CityX", "CityZ", 25);
    cityMap.addRoad("CityW", "CityV", 5);
    cityMap.addRoad("CityV", "CityY", 10);

    cout << "===== Connectivity Check =====\n";
    cout << "Are CityX and CityW connected? " << (cityMap.areLocationsConnected("CityX", "CityW") ? "Yes" : "No") << endl;
    cout << "Are CityX and CityV connected? " << (cityMap.areLocationsConnected("CityX", "CityV") ? "Yes" : "No") << endl;
    cout << "==============================\n";

    cityMap.shortestPath("CityX", "CityW");

    return 0;
}

